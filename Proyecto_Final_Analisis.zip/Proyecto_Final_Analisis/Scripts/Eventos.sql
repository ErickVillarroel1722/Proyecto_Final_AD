CREATE DATABASE server;

use Server;
-- Crear la tabla para almacenar los datos del archivo CSV
CREATE TABLE event (
    id INT ,
    Anio INT,
    Mes INT,
    Fecha_inicial DATETIME,
    Fecha_final DATETIME,
    Nombre_Evento VARCHAR(255),
    Descripcion TEXT,
    Temas VARCHAR(255),
    Ciudad VARCHAR(100),
    Lugar VARCHAR(100),
    Sitio_Web VARCHAR(255),
    Publico TEXT,
    Expositores TEXT,
    Cargo VARCHAR(255)
);


LOAD DATA INFILE 'E:/Downloads/Proyecto_Analisis-main/Bases_Datos/CSV/Eventos o noticias mundiales.csv'
INTO TABLE event
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
select * from event;
SELECT * FROM event INTO OUTFILE 'E:/Downloads/Proyecto_Analisis-main/Bases_Datos/CSV/Eventos.csv' FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n';


